#include <Arduino.h>

#include "Servo_control.h"
#include "../Position/PositionLoc.h"
#include "../kinematics/kinematics.h"
#include "Leg.h"
#include "../pwm_drivers.h"
#include "../Constants.h"

// coodPosition

Leg::Leg(LegPosition id, int16_t anchX, int16_t anchY)
{

    m_position = id;
    m_anchorX = anchX;
    m_anchorY = anchY;
    m_anchorZ = 0;

    // when initzllizing a leg, if a leg has been met, supply it with this information based on the id
    // of the position. If its the front left leg, meet this criteria, if that not it
    // switch to the next leg
    // so on and so forth
    anchorDegOffset = atan2(anchY, anchX) * Constants::Rad_to_Deg;

    switch (id)
    {
    case LegPosition::FRONT_LEFT:
        footServo.initialize("LF_Foot", Constants::LFF, false);
        kneeServo.initialize("LF_Knee", Constants::LFK, true);
        rotServo.initialize("LF_Rot", Constants::LFR, false);
        footServo.attachPWM(&pwmLeft,1);
        kneeServo.attachPWM(&pwmLeft,1);
        rotServo.attachPWM(&pwmLeft,1);
        break;

    case LegPosition::FRONT_RIGHT:
        footServo.initialize("RF_Foot", Constants::RFF, true);
        kneeServo.initialize("RF_Knee", Constants::RFK, false);
        rotServo.initialize("RF_Rot", Constants::RFR, true);
        footServo.attachPWM(&pwmRight,0);
        kneeServo.attachPWM(&pwmRight,0);
        rotServo.attachPWM(&pwmRight,0);
        break;

    case LegPosition::MIDDLE_LEFT:
        footServo.initialize("RF_Foot", Constants::LMF, false);
        kneeServo.initialize("RF_Knee", Constants::LMK, true);
        rotServo.initialize("RF_Rot", Constants::LMR, false);
        footServo.attachPWM(&pwmLeft,1);
        kneeServo.attachPWM(&pwmLeft,1);
        rotServo.attachPWM(&pwmLeft,1);
        break;

    case LegPosition::MIDDLE_RIGHT:
        footServo.initialize("RF_Foot", Constants::RMF, true);
        kneeServo.initialize("RF_Knee", Constants::RMK, false);
        rotServo.initialize("RF_Rot", Constants::RMR, true);
        footServo.attachPWM(&pwmRight,0);
        kneeServo.attachPWM(&pwmRight,0);
        rotServo.attachPWM(&pwmRight,0);
        break;

    case LegPosition::BACK_LEFT:
        footServo.initialize("RF_Foot", Constants::LBF, false);
        kneeServo.initialize("RF_Knee", Constants::LBK, true);
        rotServo.initialize("RF_Rot", Constants::LBR, false);
        footServo.attachPWM(&pwmLeft,1);
        kneeServo.attachPWM(&pwmLeft,1);
        rotServo.attachPWM(&pwmLeft,1);
        break;

    case LegPosition::BACK_RIGHT:
        footServo.initialize("RF_Foot", Constants::RBF, true);
        kneeServo.initialize("RF_Knee", Constants::RBK, false);
        rotServo.initialize("RF_Rot", Constants::RBR, true);
        footServo.attachPWM(&pwmRight,0);
        kneeServo.attachPWM(&pwmRight,0);
        rotServo.attachPWM(&pwmRight,0);
        break;
    }
}

bool Leg::setCoordPosition(PositionLoc coodPosition, uint8_t speed)
{
    // calculate foot position relative to anchor point

    // create IK object to handle most IK math functions
    InverseKinematics ik;

    // get the X,Y,Z relative to the anchor points
    float footXRel = ik.calFootPos2Anchor(coodPosition.x, m_anchorX);
    float footYRel = ik.calFootPos2Anchor(coodPosition.y, m_anchorY);
    float footZRel = ik.calFootPos2Anchor(coodPosition.z, m_anchorZ);

    // find the hip calculation
    float hipAngle = atan2(footYRel, footXRel) * Constants::Rad_to_Deg;

    // When the leg is anchored to the body, how offset is it rotated?
    hipAngle -= anchorDegOffset;

    // determine lendth distance from coxa to foot projection on ground plane
    float rotS = ik.calculateDistance(footXRel, footYRel);
    float kneeOffsetX = ik.calcKneeOfset(footXRel, rotS);
    float kneeOffsetY = ik.calcKneeOfset(footYRel, rotS);
    float kneeX = m_anchorX + kneeOffsetX;
    float kneeY = m_anchorY + kneeOffsetY;

    // Foot pos against the knee pos
    // set it so we know where we are at
    footXRel = coodPosition.x - kneeX;
    footYRel = coodPosition.y - kneeY;

    // where are the knee and foot servos?
    // well here they are!
    float kneeS = ik.calculateDistance(footXRel, footYRel);
    float footS = ik.calculateDistance(kneeS, footZRel);
    // how to find the angle
    // use law of cosines
    // three motors create three corners, thus we can use triangles to determine the angles
    // adding the Rad_to_Deg converts the information into degrees rather than radians
    float footAngle = ik.lawOfCosines(femurLength, footLength, footS) * Constants::Rad_to_Deg;
    ;

    // if all things are at 0 degree, we want the foots angle to be off set by 90 degrees.
    footAngle = footAngle - 90;

    // gives us angle B
    // the angle at the base of the knee servo
    float AngleB = ik.lawOfCosines(footS, femurLength, footLength);

    // get angle A from the triangle made from the knee to the foot and the vertical line up from the knee
    float AngleA = atan2(footZRel, kneeS);
    // now we can get the knee angle
    float kneeAngle = (AngleA + AngleB) * Constants::Rad_to_Deg;

    // save our angles for the servos, well need to compare them later
    float rotCurrentAngle = rotServo.returnTargetAngle();
    float kneeCurrentAngle = kneeServo.returnTargetAngle();
    float footCurrentAngle = footServo.returnTargetAngle();

    if (isnan(hipAngle) || isnan(kneeAngle) || isnan(footAngle))
    {
        Serial.println("IK Calculation resulted in NaN value.");
        return false;
    }

    // if we haven't returned a false value yet, set the angles
    rotServo.setAngle(hipAngle);
    kneeServo.setAngle(kneeAngle);
    footServo.setAngle(footAngle);

    // Well, now that we know what angles we want to set, set the speeds
    rotServo.setSpeed(speed);
    kneeServo.setSpeed(speed);
    footServo.setSpeed(speed);

    // update the foots posistion to the world
    m_footX = coodPosition.x;
    m_footY = coodPosition.y;
    m_footZ = coodPosition.z;

    return true;
}

void Leg::setFlexibilityMode(bool mode)
{
    footServo.setFlexabilityMode(mode);
    kneeServo.setFlexabilityMode(mode);
    rotServo.setFlexabilityMode(mode);
}
