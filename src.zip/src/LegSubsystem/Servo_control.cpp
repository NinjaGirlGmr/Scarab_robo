#include "Servo.h"
#include "../Constants.h"

void Servo::initialize(String id, uint8_t channel, bool isInverted)
{
    m_id = id;
    m_channel = channel;
    m_isInverted = isInverted;
}

void Servo::setAngle(float angle)
{
    // check for flexability mode
    angle = constrain(angle, minRot, maxRot);
    m_angle = angle;

    if (m_isInverted)
    {
        m_angle = -m_angle;
    }
    pulseWidth = map(angle, minRot, maxRot, Constants::Pulse_Width_Min, Constants::Pulse_Width_Max);
    writeMicroseconds(pulseWidth);
}

void Servo::setSpeed(uint8_t speed)
{
    this->speed = constrain(speed, Constants::min_speed, Constants::max_speed);
}

void Servo::setFlexabilityMode(bool mode)
{
    flexabilityMode = mode;
}

float Servo::estimateDistanceFromExtreme(float angle)
{
    float distanceFromExtreme = 0.0;
    if (angle > 0)
    {
        distanceFromExtreme = maxRot - angle;
    }
    else
    {
        distanceFromExtreme = angle - minRot;
    }
    return distanceFromExtreme;
}
