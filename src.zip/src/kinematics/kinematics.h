#include "math.h"
#include "../Position/PositionLoc.h"
#include <Arduino.h>
#include "../Constants.h"

#ifndef InverseKinematics_h
#define InverseKinematics_h

class InverseKinematics
{
public:
    // calculates the angles needed for each servo to reach a specific point in 3D space

    float calFootPos2Anchor(int16_t coord, int16_t anchor) { return coord - anchor; };

    // kneeOffset

    float calcKneeOfset(int16_t coord, float lengthDist) { return coord * Constants::coxa_length / lengthDist; };

    float calculateDistance(float x, float y)
    {
        return sqrt(sq(x) + sq(y));
    }

    // law of cosines, it can be used to find either the angle of length of a side of a triangle dependent on the given information.
    float lawOfCosines(float a, float b, float c)
    {
        return acos((sq(a) + sq(b) - sq(c)) / (2 * a * b));
    }
};

#endif