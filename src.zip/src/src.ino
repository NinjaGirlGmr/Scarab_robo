#include <Arduino.h>

#include <Wire.h>
#include "hexapod_base.h"
#include "pwm_drivers.h"
#include "Adafruit_PWMServoDriver.h"
#include "Constants.h"



HexapodBase hexapod;


void setup()
{
  // put your setup code here, to run once:
  Serial.begin(9600);
  Wire.begin();
  Serial.println("PCA9685 Servo Test");

  pwmRight.begin();
  pwmRight.setPWMFreq(60);

  pwmLeft.begin();
  pwmLeft.setPWMFreq(60);

  delay(10);


}

void loop()
{
  // put your main code here, to run repeatedly:

  hexapod.zeroAllLegs();
  delay(2000);

 
}
